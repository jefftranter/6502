look into msbasic.s for the README
visit www.pagetable.com for more info
